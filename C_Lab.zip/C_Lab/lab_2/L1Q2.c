#include<stdio.h>
int main()
{
    float pi=3.1415926,b=1.0/(2.0*pi);
    printf("value is= %f",b);
    
    return 0;
}